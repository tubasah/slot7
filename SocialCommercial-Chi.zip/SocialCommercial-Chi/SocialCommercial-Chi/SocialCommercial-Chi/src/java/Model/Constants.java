
package Model;


public class Constants {
    public static String GOOGLE_CLIENT_ID = "474129874362-6th87hm21qduqtih8hjjppej1e78rg08.apps.googleusercontent.com";
    public static String GOOGLE_CLIENT_SECRET = "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";
    public static String GOOGLE_REDIRECT_URI = "http://localhost:8080/SocialCommercial/LoginGoogle";
    public static String GOOGLE_LINK_GET_TOKEN = "http://accounts.google.com/o/oauth2/token";
    public static String GOOGLE_LINK_GET_USER_INFO = "http://www.googleapis.com/oauth2/v1/userinfo?access_token=";
    public static String GOOGLE_GRANT_TYPE = "authorization_code";
}
