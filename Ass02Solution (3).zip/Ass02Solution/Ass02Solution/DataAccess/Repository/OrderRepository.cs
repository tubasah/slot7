﻿using BusinessObject.Objects;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class OrderRepository : IOrderRepository
    {
        public void createOrder(Order order, OrderDetail detail)
       => OrderDAO.Instance.insertOrder(order, detail);

        public void deleteOrder(int id)
        => OrderDAO.Instance.deleteOrder(id);

        public List<OrderWithOrderDetail> getOrders()
       => OrderDAO.Instance.getOrders();

        public void updateOrder(Order order, OrderDetail detail)
        
            => OrderDAO.Instance.updateOrder(order, detail);
        
    }
}
