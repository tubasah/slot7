﻿using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public interface IMemberRepository
    {
        List<Member> GetMembers();
        Member getMemberById(int id);
        void addMember(Member member);
        void updateMember(Member member);
        void deleteMember(int id);
    }
}
