﻿using BusinessObject.Objects;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public interface IOrderRepository
    {
        void deleteOrder(int id);
        void updateOrder(Order order,OrderDetail detail);
        void createOrder(Order order,OrderDetail detail);
        List<OrderWithOrderDetail> getOrders();
    }
}
