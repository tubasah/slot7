﻿using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class MemberRepository : IMemberRepository
    {
        public void addMember(Member member)
        {
            MemberDAO.Instance.addMember(member);
        }

        public void deleteMember(int id)
        {
            MemberDAO.Instance.deleteMember(id);
        }

        public Member getMemberById(int id)
        
        =>    MemberDAO.Instance.getMember(id);
        

        public List<Member> GetMembers()
            =>    MemberDAO.Instance.getMemberList();
        

        public void updateMember(Member member)
        {
            MemberDAO.Instance.updateMember(member);
        }
    }
}
