﻿using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class ProductDAO
    {
        SaleManagermentContext context=new SaleManagermentContext();
        private static ProductDAO instance;
        private static readonly Object instancelock= new Object();
        private ProductDAO() { }
        public static ProductDAO Instance
        {
            get
            {
                lock (instancelock)
                {
                    if (instance == null)
                    {
                        instance = new ProductDAO();
                    }
                    return instance;
                }
            }
        }
        public List<Product> GetProducts()
        {
            return context.Products.ToList();
        }
        public void AddProduct(Product product)
        {
            context.Products.Add(product);
            context.SaveChanges();
        }
        public void RemoveProduct(Product product)
        {   Product productremove=context.Products.FirstOrDefault(x=>x.ProductId==product.ProductId);
            context.Products.Remove(productremove);
            context.SaveChanges() ;
        }
        public void UpdateProduct(Product product)
        {
            Product updateproduct=context.Products.FirstOrDefault(x => x.ProductId==product.ProductId);
            updateproduct.ProductName=product.ProductName;
            updateproduct.UnitPrice=product.UnitPrice;
            updateproduct.UnitslnStock=product.UnitslnStock;
            updateproduct.CategoryId=product.CategoryId;
            updateproduct.Weight=product.Weight;
            context.SaveChanges();
        }

    }
}
