﻿using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class MemberDAO
    {
        SaleManagermentContext context = new SaleManagermentContext();
        private static MemberDAO instance;
        private static readonly object instancelock= new object();
        private MemberDAO() { }
        public static MemberDAO Instance
        {
            get
            { lock (instancelock)
                {
                    if (instance == null)
                    {
                        instance = new MemberDAO();
                    }
                    return instance;
                }
      
            }
        }



        public List<Member> getMemberList()
        {
            List<Member> list;
            list=context.Members.ToList();
            return list;
        }
        public Member getMember(int id)
        {
            Member member=context.Members.FirstOrDefault(x=>x.MemberId==id);
            return member;
        }
        public void addMember(Member member)
        {
            context.Members.Add(member);
            context.SaveChanges();
        }
        public void updateMember(Member member)
        {
            Member updatemember= context.Members.FirstOrDefault(x=>x.MemberId == member.MemberId);
            updatemember.Email = member.Email;
            updatemember.CompanyName= member.CompanyName;
            updatemember.City= member.City;
            updatemember.Country= member.Country;
            updatemember.Password= member.Password;
            updatemember.MemberId= member.MemberId;
            context.SaveChanges();
        }
        public void deleteMember(int id)
        {
            Member member = context.Members.FirstOrDefault(x => x.MemberId == id);
            context.Remove(member);
            context.SaveChanges();
        }
    }
}
