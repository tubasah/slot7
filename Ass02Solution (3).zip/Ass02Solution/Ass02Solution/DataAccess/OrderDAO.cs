﻿using BusinessObject.Objects;
using SaleWinApp.Objects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class OrderDAO
    {
        public SaleManagermentContext context=new SaleManagermentContext();
        private static OrderDAO instance;
        private static readonly Object instancelock=new Object();
        private OrderDAO() { }
        public static OrderDAO Instance
        {
            get
            {
                lock (instancelock)
                {
                    if (instance == null)
                    {
                        instance = new OrderDAO();
                    }
                    return instance;
                }
            }
        }



        public void insertOrder(Order order,OrderDetail orderDetail)
        {
            context.OrderDetails.Add(orderDetail);
            context.Orders.Add(order);
            context.SaveChanges();
        }
        public void deleteOrder(int orderid)
        {
              Order order=context.Orders.FirstOrDefault(x=>x.OrderId==orderid);
            OrderDetail orderDetail=context.OrderDetails.FirstOrDefault(x=>x.OrderId==orderid);
            context.Orders.Remove(order);
            context.OrderDetails.Remove(orderDetail);
            context.SaveChanges();
        }
        public void updateOrder(Order order, OrderDetail orderDetail)
        {
            Order orderupdate = context.Orders.FirstOrDefault(x => x.OrderId == order.OrderId);
            OrderDetail orderDetailupdate = context.OrderDetails.FirstOrDefault(x => x.OrderId ==orderDetail.OrderId);
            orderupdate.OrderDate = order.OrderDate;
            orderupdate.RequiredDare = order.RequiredDare;
            orderupdate.MemberId = order.MemberId;
            orderupdate.ShippedDate = order.ShippedDate;
            orderupdate.Freight = order.Freight;
            //-----------------------------------------------
            orderDetailupdate.ProductId=orderDetail.ProductId;
            orderDetailupdate.UnitPrice = orderDetail.UnitPrice;
            

            context.SaveChanges();
        }
        public List<OrderWithOrderDetail> getOrders()
        {
            var list = from o in context.Orders
                       join od in context.OrderDetails on o.OrderId equals od.OrderId
                       join p in context.Products on od.ProductId equals p.ProductId
                       select new OrderWithOrderDetail
                       {
                           OrderId = o.OrderId,
                           MemberId = o.MemberId,
                           OrderDate = o.OrderDate,
                           RequiredDare = o.RequiredDare,
                           ShippedDate = o.ShippedDate,
                           Freight = o.Freight,
                           ProductId = od.ProductId,
                           ProductName = p.ProductName,
                           Quantity = od.Quantity,
                           UnitPrice = (decimal)od.UnitPrice,

        };
            return list.ToList();
                  
        }
    }
}
