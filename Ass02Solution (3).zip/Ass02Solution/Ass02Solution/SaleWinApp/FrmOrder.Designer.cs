﻿namespace SaleWinApp
{
    partial class FrmOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvOrder = new DataGridView();
            label1 = new Label();
            tbUnitPrice = new TextBox();
            cbProductID = new ComboBox();
            dtpShippedDate = new DateTimePicker();
            dtpRequiredDate = new DateTimePicker();
            DtpOrderDate = new DateTimePicker();
            cbMemberID = new ComboBox();
            tbQuantity = new TextBox();
            tbFreight = new TextBox();
            tbOrderID = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label10 = new Label();
            btnLoad = new Button();
            btnDelete = new Button();
            btnAdd = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvOrder).BeginInit();
            SuspendLayout();
            // 
            // dgvOrder
            // 
            dgvOrder.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrder.Location = new Point(38, 53);
            dgvOrder.Name = "dgvOrder";
            dgvOrder.RowHeadersWidth = 51;
            dgvOrder.RowTemplate.Height = 29;
            dgvOrder.Size = new Size(1322, 428);
            dgvOrder.TabIndex = 27;
            dgvOrder.CellClick += dgvOrder_CellClick;
            dgvOrder.CellDoubleClick += dgvOrder_CellDoubleClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(519, 9);
            label1.Name = "label1";
            label1.Size = new Size(324, 41);
            label1.TabIndex = 26;
            label1.Text = "QUẢN LÍ ĐƠN HÀNG";
            // 
            // tbUnitPrice
            // 
            tbUnitPrice.Location = new Point(539, 875);
            tbUnitPrice.Name = "tbUnitPrice";
            tbUnitPrice.Size = new Size(347, 27);
            tbUnitPrice.TabIndex = 45;
            // 
            // cbProductID
            // 
            cbProductID.FormattingEnabled = true;
            cbProductID.Location = new Point(539, 770);
            cbProductID.Name = "cbProductID";
            cbProductID.Size = new Size(151, 28);
            cbProductID.TabIndex = 44;
            // 
            // dtpShippedDate
            // 
            dtpShippedDate.Location = new Point(539, 675);
            dtpShippedDate.Name = "dtpShippedDate";
            dtpShippedDate.Size = new Size(250, 27);
            dtpShippedDate.TabIndex = 43;
            // 
            // dtpRequiredDate
            // 
            dtpRequiredDate.Location = new Point(539, 624);
            dtpRequiredDate.Name = "dtpRequiredDate";
            dtpRequiredDate.Size = new Size(250, 27);
            dtpRequiredDate.TabIndex = 42;
            // 
            // DtpOrderDate
            // 
            DtpOrderDate.Location = new Point(539, 575);
            DtpOrderDate.Name = "DtpOrderDate";
            DtpOrderDate.Size = new Size(250, 27);
            DtpOrderDate.TabIndex = 41;
            // 
            // cbMemberID
            // 
            cbMemberID.FormattingEnabled = true;
            cbMemberID.Location = new Point(539, 533);
            cbMemberID.Name = "cbMemberID";
            cbMemberID.Size = new Size(151, 28);
            cbMemberID.TabIndex = 40;
            // 
            // tbQuantity
            // 
            tbQuantity.Location = new Point(539, 815);
            tbQuantity.Name = "tbQuantity";
            tbQuantity.Size = new Size(347, 27);
            tbQuantity.TabIndex = 39;
            // 
            // tbFreight
            // 
            tbFreight.Location = new Point(539, 717);
            tbFreight.Name = "tbFreight";
            tbFreight.Size = new Size(347, 27);
            tbFreight.TabIndex = 38;
            // 
            // tbOrderID
            // 
            tbOrderID.Location = new Point(539, 493);
            tbOrderID.Name = "tbOrderID";
            tbOrderID.Size = new Size(347, 27);
            tbOrderID.TabIndex = 37;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(424, 875);
            label9.Name = "label9";
            label9.Size = new Size(72, 20);
            label9.TabIndex = 36;
            label9.Text = "Unit Price";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(422, 822);
            label8.Name = "label8";
            label8.Size = new Size(65, 20);
            label8.TabIndex = 35;
            label8.Text = "Quantity";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(424, 773);
            label7.Name = "label7";
            label7.Size = new Size(75, 20);
            label7.TabIndex = 34;
            label7.Text = "ProductID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(422, 720);
            label6.Name = "label6";
            label6.Size = new Size(55, 20);
            label6.TabIndex = 33;
            label6.Text = "Freight";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(422, 675);
            label5.Name = "label5";
            label5.Size = new Size(96, 20);
            label5.TabIndex = 32;
            label5.Text = "5hippedDate";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(424, 629);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 31;
            label4.Text = "RequiredDare";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(423, 582);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 30;
            label3.Text = "OrderDate";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(424, 536);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 29;
            label2.Text = "MemberID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(422, 496);
            label10.Name = "label10";
            label10.Size = new Size(62, 20);
            label10.TabIndex = 28;
            label10.Text = "OrderID";
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(477, 917);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 48;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(778, 917);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 47;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(630, 917);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 46;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // FrmOrder
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1387, 988);
            Controls.Add(btnLoad);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(tbUnitPrice);
            Controls.Add(cbProductID);
            Controls.Add(dtpShippedDate);
            Controls.Add(dtpRequiredDate);
            Controls.Add(DtpOrderDate);
            Controls.Add(cbMemberID);
            Controls.Add(tbQuantity);
            Controls.Add(tbFreight);
            Controls.Add(tbOrderID);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label10);
            Controls.Add(dgvOrder);
            Controls.Add(label1);
            Name = "FrmOrder";
            Text = "FrmOrder";
            Load += FrmOrder_Load;
            ((System.ComponentModel.ISupportInitialize)dgvOrder).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dgvOrder;
        private Label label1;
        private TextBox tbUnitPrice;
        private ComboBox cbProductID;
        private DateTimePicker dtpShippedDate;
        private DateTimePicker dtpRequiredDate;
        private DateTimePicker DtpOrderDate;
        private ComboBox cbMemberID;
        private TextBox tbQuantity;
        private TextBox tbFreight;
        private TextBox tbOrderID;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label10;
        private Button btnLoad;
        private Button btnDelete;
        private Button btnAdd;
    }
}