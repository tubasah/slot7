﻿using DataAccess.Repository;
using Microsoft.IdentityModel.Tokens;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmMember : Form
    {
        IMemberRepository MemberRepository = new MemberRepository();
        public frmMember()
        {
            InitializeComponent();
        }

        private void frmMember_Load(object sender, EventArgs e)
        {
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmMemberDetail frmMemberDetail = new frmMemberDetail
            {
                update = false,
                Text = "Add member",
                MemberRepository = MemberRepository
            };
            frmMemberDetail.Show();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvMember.DataSource = MemberRepository.GetMembers();

        }

        private void dgvMember_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbMemberID.Text = dgvMember.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            tbEmail.Text = dgvMember.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
            tbCompanyName.Text = dgvMember.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
            tbCity.Text = dgvMember.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
            tbCountry.Text = dgvMember.Rows[e.RowIndex].Cells[4].FormattedValue.ToString();
            tbPassWord.Text = dgvMember.Rows[e.RowIndex].Cells[5].FormattedValue.ToString();
            frmMemberDetail frmMemberDetail = new frmMemberDetail
            {
                MemberInfo = new Member
                {
                    CompanyName = tbCompanyName.Text,
                    City = tbCity.Text,
                    Country = tbCountry.Text,
                    MemberId = int.Parse(tbMemberID.Text),
                    Email = tbEmail.Text,
                    Password = tbPassWord.Text,
                },
                update = true,
                Text = "Update member",
                MemberRepository = MemberRepository
            };
            frmMemberDetail.Show();
        }

        private void dgvMember_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbMemberID.Text = dgvMember.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            tbEmail.Text = dgvMember.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
            tbCompanyName.Text = dgvMember.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
            tbCity.Text = dgvMember.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
            tbCountry.Text = dgvMember.Rows[e.RowIndex].Cells[4].FormattedValue.ToString();
            tbPassWord.Text = dgvMember.Rows[e.RowIndex].Cells[5].FormattedValue.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string memberIdText = tbMemberID.Text;
            if (!string.IsNullOrEmpty(memberIdText))
            {
                int id = int.Parse(memberIdText);
                MemberRepository.deleteMember(id);
                dgvMember.DataSource = MemberRepository.GetMembers();
                MessageBox.Show("Xóa thành công !!!");
            }
            else
            {
                MessageBox.Show("Vui lòng nhập Member ID.");
            }
        }


    }
}
