﻿using DataAccess.Repository;
using Microsoft.EntityFrameworkCore.Infrastructure;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmProduct : Form
    {
        IProductRepository productRepository = new ProductRepository();
        public frmProduct()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvProduct.DataSource = productRepository.getListProduct();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmProductDetail detail = new frmProductDetail
            {
                update = false
            ,
                Text = "Add Product"
            };
            detail.Show();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbProductID.Text = dgvProduct.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            tbCategoryID.Text = dgvProduct.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
            tbProductName.Text = dgvProduct.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
            tbWeight.Text = dgvProduct.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
            tbUnitPrice.Text = dgvProduct.Rows[e.RowIndex].Cells[4].FormattedValue.ToString();
            tbUnitslnStock.Text = dgvProduct.Rows[e.RowIndex].Cells[5].FormattedValue.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (tbProductID.Text.Length != 0)
            {
                int ProductId = int.Parse(tbProductID.Text);
                Product product = new Product
                {
                    ProductId = ProductId
                };
                productRepository.removeProduct(product);
                tbProductID.Clear();
                dgvProduct.DataSource = productRepository.getListProduct();
                MessageBox.Show("Xóa thành công !!!");

            }
            else
            {
                MessageBox.Show("Lỗi định dạng hoặc sản phẩm đó bạn đã xóa rồi !!!");
            }

        }

        private void dgvProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbProductID.Text = dgvProduct.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            tbCategoryID.Text = dgvProduct.Rows[e.RowIndex].Cells[1].FormattedValue.ToString();
            tbProductName.Text = dgvProduct.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
            tbWeight.Text = dgvProduct.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
            tbUnitPrice.Text = dgvProduct.Rows[e.RowIndex].Cells[4].FormattedValue.ToString();
            tbUnitslnStock.Text = dgvProduct.Rows[e.RowIndex].Cells[5].FormattedValue.ToString();
            Product product1 = new Product
            {
                ProductId = int.Parse(tbProductID.Text),
                ProductName = tbProductName.Text,
                UnitPrice = decimal.Parse(tbUnitPrice.Text),
                CategoryId = int.Parse(tbCategoryID.Text),
                Weight = tbWeight.Text,
                UnitslnStock = int.Parse(tbUnitslnStock.Text),
            };
            frmProductDetail frmproductdetail = new frmProductDetail
            {
                productinfo = product1,
                update = true,
                Text = "Update Product"
            };
            frmproductdetail.Show();
        }

        private void dgvProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
