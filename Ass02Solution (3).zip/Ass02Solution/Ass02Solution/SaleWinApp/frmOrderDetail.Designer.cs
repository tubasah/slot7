﻿namespace SaleWinApp
{
    partial class frmOrderDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            tbOrderID = new TextBox();
            tbFreight = new TextBox();
            tbQuantity = new TextBox();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            folderBrowserDialog1 = new FolderBrowserDialog();
            sqlCommand2 = new Microsoft.Data.SqlClient.SqlCommand();
            cbMemberID = new ComboBox();
            DtpOrderDate = new DateTimePicker();
            dtpRequiredDate = new DateTimePicker();
            dtpShippedDate = new DateTimePicker();
            cbProductID = new ComboBox();
            tbUnitPrice = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 24);
            label1.Name = "label1";
            label1.Size = new Size(62, 20);
            label1.TabIndex = 0;
            label1.Text = "OrderID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(49, 64);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 1;
            label2.Text = "MemberID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 110);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 2;
            label3.Text = "OrderDate";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(49, 157);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 3;
            label4.Text = "RequiredDare";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(47, 203);
            label5.Name = "label5";
            label5.Size = new Size(96, 20);
            label5.TabIndex = 4;
            label5.Text = "5hippedDate";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(47, 248);
            label6.Name = "label6";
            label6.Size = new Size(55, 20);
            label6.TabIndex = 5;
            label6.Text = "Freight";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(49, 301);
            label7.Name = "label7";
            label7.Size = new Size(75, 20);
            label7.TabIndex = 6;
            label7.Text = "ProductID";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(47, 350);
            label8.Name = "label8";
            label8.Size = new Size(65, 20);
            label8.TabIndex = 7;
            label8.Text = "Quantity";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(49, 403);
            label9.Name = "label9";
            label9.Size = new Size(72, 20);
            label9.TabIndex = 8;
            label9.Text = "Unit Price";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(320, 464);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 14;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(164, 464);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(94, 29);
            btnSave.TabIndex = 13;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // tbOrderID
            // 
            tbOrderID.Location = new Point(164, 21);
            tbOrderID.Name = "tbOrderID";
            tbOrderID.Size = new Size(347, 27);
            tbOrderID.TabIndex = 15;
            // 
            // tbFreight
            // 
            tbFreight.Location = new Point(164, 245);
            tbFreight.Name = "tbFreight";
            tbFreight.Size = new Size(347, 27);
            tbFreight.TabIndex = 16;
            // 
            // tbQuantity
            // 
            tbQuantity.Location = new Point(164, 343);
            tbQuantity.Name = "tbQuantity";
            tbQuantity.Size = new Size(347, 27);
            tbQuantity.TabIndex = 17;
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // sqlCommand2
            // 
            sqlCommand2.CommandTimeout = 30;
            sqlCommand2.EnableOptimizedParameterBinding = false;
            // 
            // cbMemberID
            // 
            cbMemberID.FormattingEnabled = true;
            cbMemberID.Location = new Point(164, 61);
            cbMemberID.Name = "cbMemberID";
            cbMemberID.Size = new Size(151, 28);
            cbMemberID.TabIndex = 18;
            // 
            // DtpOrderDate
            // 
            DtpOrderDate.Location = new Point(164, 103);
            DtpOrderDate.Name = "DtpOrderDate";
            DtpOrderDate.Size = new Size(250, 27);
            DtpOrderDate.TabIndex = 19;
            // 
            // dtpRequiredDate
            // 
            dtpRequiredDate.Location = new Point(164, 152);
            dtpRequiredDate.Name = "dtpRequiredDate";
            dtpRequiredDate.Size = new Size(250, 27);
            dtpRequiredDate.TabIndex = 20;
            // 
            // dtpShippedDate
            // 
            dtpShippedDate.Location = new Point(164, 203);
            dtpShippedDate.Name = "dtpShippedDate";
            dtpShippedDate.Size = new Size(250, 27);
            dtpShippedDate.TabIndex = 21;
            // 
            // cbProductID
            // 
            cbProductID.FormattingEnabled = true;
            cbProductID.Location = new Point(164, 298);
            cbProductID.Name = "cbProductID";
            cbProductID.Size = new Size(151, 28);
            cbProductID.TabIndex = 22;
            cbProductID.SelectedIndexChanged += cbProductID_SelectedIndexChanged;
            // 
            // tbUnitPrice
            // 
            tbUnitPrice.Location = new Point(164, 403);
            tbUnitPrice.Name = "tbUnitPrice";
            tbUnitPrice.Size = new Size(347, 27);
            tbUnitPrice.TabIndex = 23;
            // 
            // frmOrderDetail
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(570, 505);
            Controls.Add(tbUnitPrice);
            Controls.Add(cbProductID);
            Controls.Add(dtpShippedDate);
            Controls.Add(dtpRequiredDate);
            Controls.Add(DtpOrderDate);
            Controls.Add(cbMemberID);
            Controls.Add(tbQuantity);
            Controls.Add(tbFreight);
            Controls.Add(tbOrderID);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmOrderDetail";
            Text = "frmOrderDetail";
            Load += frmOrderDetail_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button btnCancel;
        private Button btnSave;
        private TextBox tbOrderID;
        private TextBox tbFreight;
        private TextBox tbQuantity;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private FolderBrowserDialog folderBrowserDialog1;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand2;
        private ComboBox cbMemberID;
        private DateTimePicker DtpOrderDate;
        private DateTimePicker dtpRequiredDate;
        private DateTimePicker dtpShippedDate;
        private ComboBox cbProductID;
        private TextBox tbUnitPrice;
    }
}