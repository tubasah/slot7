﻿using BusinessObject.Objects;
using DataAccess.Repository;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmOrderDetail : Form
    {
        IMemberRepository memberRepository = new MemberRepository();
        IProductRepository productRepository = new ProductRepository();
        IOrderRepository orderRepository = new OrderRepository();
        public bool update { get; set; }
        public OrderWithOrderDetail orderinfo { get; set; }
        public frmOrderDetail()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (update == false)
            {
                try
                {
                    if (int.TryParse(cbMemberID.SelectedValue?.ToString(), out int memberId) &&
                        decimal.TryParse(tbFreight.Text, out decimal freight) &&
                        int.TryParse(cbProductID.SelectedValue?.ToString(), out int productId) &&
                        int.TryParse(tbQuantity.Text, out int quantity) &&
                        decimal.TryParse(tbUnitPrice.Text, out decimal unitPrice))
                    {
                        Order order = new Order
                        {
                            OrderId = int.Parse(tbOrderID.Text),
                            MemberId = memberId,
                            OrderDate = DtpOrderDate.Value,
                            RequiredDare = dtpRequiredDate.Value,
                            ShippedDate = dtpShippedDate.Value,
                            Freight = freight,
                        };

                        OrderDetail orderDetail = new OrderDetail
                        {
                            OrderId = int.Parse(tbOrderID.Text),
                            ProductId = productId,
                            Quantity = quantity,
                            UnitPrice = unitPrice,
                        };

                        orderRepository.createOrder(order, orderDetail);
                        MessageBox.Show("Thêm thành công !!!");
                    }
                    else
                    {
                        MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra giá trị đầu vào.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("OrderID đã tồn tại. Vui lòng chọn id khác");
                }
            }
            if (update == true)
            {
                try
                {
                    tbOrderID.ReadOnly = true;
                    if (int.TryParse(cbMemberID.SelectedValue?.ToString(), out int memberId) &&
                        decimal.TryParse(tbFreight.Text, out decimal freight) &&
                        int.TryParse(cbProductID.SelectedValue?.ToString(), out int productId) &&
                        int.TryParse(tbQuantity.Text, out int quantity) &&
                        decimal.TryParse(tbUnitPrice.Text, out decimal unitPrice))
                    {
                       
                        Order orderup = new Order
                        {
                            OrderId = int.Parse(tbOrderID.Text),
                            MemberId = memberId,
                            OrderDate = DtpOrderDate.Value,
                            RequiredDare = dtpRequiredDate.Value,
                            ShippedDate = dtpShippedDate.Value,
                            Freight = freight,
                        };

                        OrderDetail orderDetailup = new OrderDetail
                        {
                            OrderId = int.Parse(tbOrderID.Text),
                            ProductId = productId,
                            Quantity = quantity,
                            UnitPrice = unitPrice,
                        };
                        orderRepository.updateOrder(orderup, orderDetailup);
                        MessageBox.Show("UPDATE THÀNH CÔNG !!!");
                    }
                    else
                    {
                        MessageBox.Show("Dữ liệu không hợp lệ. Vui lòng kiểm tra giá trị đầu vào.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("OrderID đã tồn tại. Vui lòng chọn id khác");
                }
            }
        }

        private void frmOrderDetail_Load(object sender, EventArgs e)
        {

            var listproduct = productRepository.getListProduct().ToList();
            var listproductid = listproduct.Select(x => x.ProductId).ToList();
            cbProductID.DataSource = listproductid.ToList();
            var listmember = memberRepository.GetMembers().ToList();
            var listmemberid = listmember.Select(x => x.MemberId).ToList();
            cbMemberID.DataSource = listmemberid.ToList();
            if (update == true)
            {
                tbOrderID.ReadOnly = true;
                tbOrderID.Text = orderinfo.OrderId.ToString();
                tbFreight.Text = orderinfo.Freight.ToString();
                tbQuantity.Text = orderinfo.Quantity.ToString();
                cbMemberID.SelectedItem = orderinfo.MemberId;
                cbProductID.SelectedItem = orderinfo.ProductId;
                DtpOrderDate.Value = (DateTime)(orderinfo.OrderDate != null ? orderinfo.OrderDate : DtpOrderDate.Value);
                dtpRequiredDate.Value = (DateTime)(orderinfo.RequiredDare != null ? orderinfo.RequiredDare: dtpRequiredDate.Value);
                dtpShippedDate.Value = (DateTime)(orderinfo.ShippedDate != null ? orderinfo.ShippedDate : dtpShippedDate.Value);
                DtpOrderDate.Value = orderinfo.OrderDate;

            }

        }

        private void cbProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedproductid = (int)cbProductID.SelectedValue;
            Product product = productRepository.getListProduct().FirstOrDefault(x => x.ProductId == selectedproductid);
            tbUnitPrice.Text = product.UnitPrice.ToString();

        }
    }
}
