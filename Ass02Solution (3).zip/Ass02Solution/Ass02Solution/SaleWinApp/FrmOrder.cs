﻿using BusinessObject.Objects;
using DataAccess.Repository;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class FrmOrder : Form
    {
        IOrderRepository orderRepository = new OrderRepository();
        IMemberRepository memberRepository = new MemberRepository();
        IProductRepository productRepository = new ProductRepository();
        public FrmOrder()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            dgvOrder.DataSource = orderRepository.getOrders();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmOrderDetail frmOrderDetail = new frmOrderDetail
            {
                update = false,
                Text = "Create Order"

            };
            frmOrderDetail.Show();
        }

        private void FrmOrder_Load(object sender, EventArgs e)
        {

            var listproduct = productRepository.getListProduct().ToList();
            var listproductid = listproduct.Select(x => x.ProductId).ToList();
            cbProductID.DataSource = listproductid.ToList();
            var listmember = memberRepository.GetMembers().ToList();
            var listmemberid = listmember.Select(x => x.MemberId).ToList();
            cbMemberID.DataSource = listmemberid.ToList();
        }

        private void dgvOrder_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbOrderID.Text = dgvOrder.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            int id = int.Parse(tbOrderID.Text);
            OrderWithOrderDetail order = orderRepository.getOrders().FirstOrDefault(x => x.OrderId == id);
            frmOrderDetail frmOrderDetail = new frmOrderDetail
            {
                orderinfo = order,
                update = true,
                Text = "Update Orrder"
            };
            frmOrderDetail.Show();


        }

        private void dgvOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
            {
                return;
            }
            tbOrderID.Text = dgvOrder.Rows[e.RowIndex].Cells[0].FormattedValue.ToString();
            int id = int.Parse(tbOrderID.Text);
            OrderWithOrderDetail orderinfo = orderRepository.getOrders().FirstOrDefault(x => x.OrderId == id);
            tbOrderID.Text = orderinfo.OrderId.ToString();
            tbFreight.Text = orderinfo.Freight.ToString();
            tbQuantity.Text = orderinfo.Quantity.ToString();
            cbMemberID.SelectedItem = orderinfo.MemberId;
            cbProductID.SelectedItem = orderinfo.ProductId;
            DtpOrderDate.Value = (DateTime)(orderinfo.OrderDate != null ? orderinfo.OrderDate : DtpOrderDate.Value);
            dtpRequiredDate.Value = (DateTime)(orderinfo.RequiredDare != null ? orderinfo.RequiredDare : dtpRequiredDate.Value);
            dtpShippedDate.Value = (DateTime)(orderinfo.ShippedDate != null ? orderinfo.ShippedDate : dtpShippedDate.Value);
            DtpOrderDate.Value = orderinfo.OrderDate;



        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(tbOrderID.Text);

                orderRepository.deleteOrder(id);
                dgvOrder.DataSource = orderRepository.getOrders();
                tbOrderID.Clear();
                MessageBox.Show("Xóa thành công !!!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Bạn chưa chọn orderid muốn xóa");
            }

        }
    }
}

