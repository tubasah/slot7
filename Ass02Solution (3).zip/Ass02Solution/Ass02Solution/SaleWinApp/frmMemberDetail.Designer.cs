﻿namespace SaleWinApp
{
    partial class frmMemberDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tbEmail = new TextBox();
            tbCompanyName = new TextBox();
            tbCountry = new TextBox();
            tbCity = new TextBox();
            tbPassWord = new TextBox();
            btnSave = new Button();
            btnCancel = new Button();
            MemberID = new Label();
            tbMemberId = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 66);
            label1.Name = "label1";
            label1.Size = new Size(46, 20);
            label1.TabIndex = 0;
            label1.Text = "Email";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 123);
            label2.Name = "label2";
            label2.Size = new Size(116, 20);
            label2.TabIndex = 1;
            label2.Text = "Company Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 226);
            label3.Name = "label3";
            label3.Size = new Size(60, 20);
            label3.TabIndex = 2;
            label3.Text = "Country";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 283);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 4;
            label5.Text = "Password";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(23, 175);
            label6.Name = "label6";
            label6.Size = new Size(34, 20);
            label6.TabIndex = 5;
            label6.Text = "City";
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(145, 59);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(272, 27);
            tbEmail.TabIndex = 6;
            // 
            // tbCompanyName
            // 
            tbCompanyName.Location = new Point(145, 116);
            tbCompanyName.Name = "tbCompanyName";
            tbCompanyName.Size = new Size(272, 27);
            tbCompanyName.TabIndex = 7;
            // 
            // tbCountry
            // 
            tbCountry.Location = new Point(145, 219);
            tbCountry.Name = "tbCountry";
            tbCountry.Size = new Size(272, 27);
            tbCountry.TabIndex = 8;
            // 
            // tbCity
            // 
            tbCity.Location = new Point(145, 172);
            tbCity.Name = "tbCity";
            tbCity.Size = new Size(272, 27);
            tbCity.TabIndex = 9;
            // 
            // tbPassWord
            // 
            tbPassWord.Location = new Point(145, 276);
            tbPassWord.Name = "tbPassWord";
            tbPassWord.Size = new Size(272, 27);
            tbPassWord.TabIndex = 10;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(104, 315);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(94, 29);
            btnSave.TabIndex = 11;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(281, 315);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 12;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // MemberID
            // 
            MemberID.AutoSize = true;
            MemberID.Location = new Point(23, 15);
            MemberID.Name = "MemberID";
            MemberID.Size = new Size(80, 20);
            MemberID.TabIndex = 13;
            MemberID.Text = "MemberID";
            // 
            // tbMemberId
            // 
            tbMemberId.Location = new Point(145, 12);
            tbMemberId.Name = "tbMemberId";
            tbMemberId.Size = new Size(272, 27);
            tbMemberId.TabIndex = 14;
            // 
            // frmMemberDetail
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(481, 356);
            Controls.Add(tbMemberId);
            Controls.Add(MemberID);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(tbPassWord);
            Controls.Add(tbCity);
            Controls.Add(tbCountry);
            Controls.Add(tbCompanyName);
            Controls.Add(tbEmail);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmMemberDetail";
            Text = "frmMemberDetail";
            Load += frmMemberDetail_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label6;
        private System.Windows.Forms.Timer timer1;
        private TextBox tbEmail;
        private TextBox tbCompanyName;
        private TextBox tbCountry;
        private TextBox tbCity;
        private TextBox tbPassWord;
        private Button btnSave;
        private Button btnCancel;
        private Label MemberID;
        private TextBox tbMemberId;
    }
}