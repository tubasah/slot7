﻿using DataAccess.Repository;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmMemberDetail : Form
    {
        public bool update { get; set; }
        public Member MemberInfo { get; set; }
        public IMemberRepository MemberRepository { get; set; }
        public frmMemberDetail()
        {
            InitializeComponent();
        }

        private void frmMemberDetail_Load(object sender, EventArgs e)
        {
            tbMemberId.ReadOnly = true;
            if (update)
            {
                tbMemberId.Text = MemberInfo.MemberId.ToString();
                tbCompanyName.Text = MemberInfo.CompanyName;
                tbCity.Text = MemberInfo.City;
                tbCountry.Text = MemberInfo.Country;
                tbEmail.Text = MemberInfo.Email;
                tbPassWord.Text = MemberInfo.Password;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Member member = new Member
            {
                Email = tbEmail.Text,
                Password = tbPassWord.Text,
                City = tbCity.Text,
                CompanyName = tbCompanyName.Text,
                Country = tbCountry.Text
            };
            if (update == true)
            {
                Member member1 = new Member
                {
                    MemberId = int.Parse(tbMemberId.Text),
                    Email = tbEmail.Text,
                    Password = tbPassWord.Text,
                    City = tbCity.Text,
                    CompanyName = tbCompanyName.Text,
                    Country = tbCountry.Text
                };
                MemberRepository.updateMember(member1);
                MessageBox.Show("Update thành công !!!");
            }
            if (update == false)
            {
                MemberRepository.addMember(member);
                MessageBox.Show("Thêm thành công !!!");
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();

        }
    }
}
