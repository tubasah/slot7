﻿using DataAccess.Repository;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class FrmLogin : Form
    {
        IMemberRepository memberRepository=new MemberRepository();
        SaleManagermentContext context=new SaleManagermentContext();
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            String email=tbEmail.Text;
            String pass=tbPass.Text;

           Member member= context.Members.FirstOrDefault(x => x.Email.Equals(email) && x.Password.Equals(pass));
            if (member != null)
            {
                if(member.Email.Equals("admin")) {

                }
                else 
                {

                }
            }
            if (member == null)
            {
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu sai !!!");
            }

        }
    }
}
