﻿namespace SaleWinApp
{
    partial class frmProductDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbCategoryID = new TextBox();
            tbWeight = new TextBox();
            tbUnitslnStock = new TextBox();
            tbUnitPrice = new TextBox();
            tbProductName = new TextBox();
            tbProductID = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnCancel = new Button();
            btnSave = new Button();
            SuspendLayout();
            // 
            // tbCategoryID
            // 
            tbCategoryID.Location = new Point(168, 85);
            tbCategoryID.Name = "tbCategoryID";
            tbCategoryID.Size = new Size(288, 27);
            tbCategoryID.TabIndex = 38;
            // 
            // tbWeight
            // 
            tbWeight.Location = new Point(168, 193);
            tbWeight.Name = "tbWeight";
            tbWeight.Size = new Size(288, 27);
            tbWeight.TabIndex = 37;
            // 
            // tbUnitslnStock
            // 
            tbUnitslnStock.Location = new Point(168, 309);
            tbUnitslnStock.Name = "tbUnitslnStock";
            tbUnitslnStock.Size = new Size(288, 27);
            tbUnitslnStock.TabIndex = 36;
            // 
            // tbUnitPrice
            // 
            tbUnitPrice.Location = new Point(168, 254);
            tbUnitPrice.Name = "tbUnitPrice";
            tbUnitPrice.Size = new Size(288, 27);
            tbUnitPrice.TabIndex = 35;
            // 
            // tbProductName
            // 
            tbProductName.Location = new Point(168, 140);
            tbProductName.Name = "tbProductName";
            tbProductName.Size = new Size(288, 27);
            tbProductName.TabIndex = 34;
            // 
            // tbProductID
            // 
            tbProductID.Location = new Point(168, 32);
            tbProductID.Name = "tbProductID";
            tbProductID.Size = new Size(288, 27);
            tbProductID.TabIndex = 33;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(51, 316);
            label6.Name = "label6";
            label6.Size = new Size(90, 20);
            label6.TabIndex = 32;
            label6.Text = "UnitslnStock";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(51, 254);
            label5.Name = "label5";
            label5.Size = new Size(68, 20);
            label5.TabIndex = 31;
            label5.Text = "UnitPrice";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(51, 200);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 30;
            label4.Text = "Weight";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(51, 147);
            label3.Name = "label3";
            label3.Size = new Size(100, 20);
            label3.TabIndex = 29;
            label3.Text = "ProductName";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(51, 92);
            label2.Name = "label2";
            label2.Size = new Size(88, 20);
            label2.TabIndex = 28;
            label2.Text = "Category ID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(51, 39);
            label1.Name = "label1";
            label1.Size = new Size(79, 20);
            label1.TabIndex = 27;
            label1.Text = "Product ID";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(303, 368);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(94, 29);
            btnCancel.TabIndex = 43;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(123, 368);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(91, 29);
            btnSave.TabIndex = 42;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // frmProductDetail
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(524, 438);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(tbCategoryID);
            Controls.Add(tbWeight);
            Controls.Add(tbUnitslnStock);
            Controls.Add(tbUnitPrice);
            Controls.Add(tbProductName);
            Controls.Add(tbProductID);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmProductDetail";
            Text = "frmProductDetail";
            Load += frmProductDetail_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox tbCategoryID;
        private TextBox tbWeight;
        private TextBox tbUnitslnStock;
        private TextBox tbUnitPrice;
        private TextBox tbProductName;
        private TextBox tbProductID;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnCancel;
        private Button btnSave;
    }
}