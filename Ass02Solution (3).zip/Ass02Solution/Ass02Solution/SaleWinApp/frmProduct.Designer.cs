﻿namespace SaleWinApp
{
    partial class frmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            tbProductID = new TextBox();
            tbProductName = new TextBox();
            tbUnitPrice = new TextBox();
            tbUnitslnStock = new TextBox();
            tbWeight = new TextBox();
            tbCategoryID = new TextBox();
            dgvProduct = new DataGridView();
            label7 = new Label();
            btnLoad = new Button();
            btnDelete = new Button();
            btnAdd = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(589, 92);
            label1.Name = "label1";
            label1.Size = new Size(79, 20);
            label1.TabIndex = 0;
            label1.Text = "Product ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(589, 145);
            label2.Name = "label2";
            label2.Size = new Size(88, 20);
            label2.TabIndex = 1;
            label2.Text = "Category ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(589, 200);
            label3.Name = "label3";
            label3.Size = new Size(100, 20);
            label3.TabIndex = 2;
            label3.Text = "ProductName";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(589, 253);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 3;
            label4.Text = "Weight";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(589, 307);
            label5.Name = "label5";
            label5.Size = new Size(68, 20);
            label5.TabIndex = 4;
            label5.Text = "UnitPrice";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(589, 369);
            label6.Name = "label6";
            label6.Size = new Size(90, 20);
            label6.TabIndex = 5;
            label6.Text = "UnitslnStock";
            // 
            // tbProductID
            // 
            tbProductID.Location = new Point(706, 85);
            tbProductID.Name = "tbProductID";
            tbProductID.Size = new Size(288, 27);
            tbProductID.TabIndex = 6;
            // 
            // tbProductName
            // 
            tbProductName.Location = new Point(706, 193);
            tbProductName.Name = "tbProductName";
            tbProductName.Size = new Size(288, 27);
            tbProductName.TabIndex = 7;
            // 
            // tbUnitPrice
            // 
            tbUnitPrice.Location = new Point(706, 307);
            tbUnitPrice.Name = "tbUnitPrice";
            tbUnitPrice.Size = new Size(288, 27);
            tbUnitPrice.TabIndex = 8;
            // 
            // tbUnitslnStock
            // 
            tbUnitslnStock.Location = new Point(706, 362);
            tbUnitslnStock.Name = "tbUnitslnStock";
            tbUnitslnStock.Size = new Size(288, 27);
            tbUnitslnStock.TabIndex = 9;
            // 
            // tbWeight
            // 
            tbWeight.Location = new Point(706, 246);
            tbWeight.Name = "tbWeight";
            tbWeight.Size = new Size(288, 27);
            tbWeight.TabIndex = 10;
            // 
            // tbCategoryID
            // 
            tbCategoryID.Location = new Point(706, 138);
            tbCategoryID.Name = "tbCategoryID";
            tbCategoryID.Size = new Size(288, 27);
            tbCategoryID.TabIndex = 11;
            // 
            // dgvProduct
            // 
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProduct.Location = new Point(25, 85);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.RowHeadersWidth = 51;
            dgvProduct.RowTemplate.Height = 29;
            dgvProduct.Size = new Size(528, 406);
            dgvProduct.TabIndex = 12;
            dgvProduct.CellClick += dataGridView1_CellClick;
            dgvProduct.CellContentClick += dgvProduct_CellContentClick;
            dgvProduct.CellDoubleClick += dgvProduct_CellDoubleClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(373, 19);
            label7.Name = "label7";
            label7.Size = new Size(321, 41);
            label7.TabIndex = 13;
            label7.Text = "QUẢN LÍ SẢN PHẨM";
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(593, 439);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(94, 29);
            btnLoad.TabIndex = 26;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(894, 439);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 25;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(746, 439);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 24;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // frmProduct
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1021, 517);
            Controls.Add(btnLoad);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(label7);
            Controls.Add(dgvProduct);
            Controls.Add(tbCategoryID);
            Controls.Add(tbWeight);
            Controls.Add(tbUnitslnStock);
            Controls.Add(tbUnitPrice);
            Controls.Add(tbProductName);
            Controls.Add(tbProductID);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmProduct";
            Text = "frmProduct";
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox tbProductID;
        private TextBox tbProductName;
        private TextBox tbUnitPrice;
        private TextBox tbUnitslnStock;
        private TextBox tbWeight;
        private TextBox tbCategoryID;
        private DataGridView dgvProduct;
        private Label label7;
        private Button btnLoad;
        private Button btnDelete;
        private Button btnAdd;
    }
}