﻿using DataAccess.Repository;
using SaleWinApp.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaleWinApp
{
    public partial class frmProductDetail : Form
    {
        IProductRepository productRepository = new ProductRepository();
        public bool update { get; set; }
        public Product productinfo { get; set; }
        public frmProductDetail()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (update == false)
            {
                Product product = new Product
                {
                    ProductName = tbProductName.Text,
                    UnitPrice = int.Parse(tbUnitPrice.Text),
                    CategoryId = int.Parse(tbCategoryID.Text),
                    UnitslnStock = int.Parse(tbUnitslnStock.Text),
                    Weight = tbWeight.Text
                };
                productRepository.addProduct(product);
                MessageBox.Show("Thêm thành công !!!");
            }
            if (update == true)
            {
                Product product = new Product
                {
                    ProductId = int.Parse(tbProductID.Text),
                    ProductName = tbProductName.Text,
                    UnitPrice = int.Parse(tbUnitPrice.Text),
                    CategoryId = int.Parse(tbCategoryID.Text),
                    UnitslnStock = int.Parse(tbUnitslnStock.Text),
                    Weight = tbWeight.Text
                };
                productRepository.updateProduct(product);
                MessageBox.Show("Update thành công !!!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmProductDetail_Load(object sender, EventArgs e)
        {

            tbProductID.ReadOnly = true;
            if (update == true)
            {
                tbProductID.Text = productinfo.ProductId.ToString();
                tbCategoryID.Text = productinfo.CategoryId.ToString();
                tbUnitslnStock.Text = productinfo.UnitslnStock.ToString();
                tbProductName.Text = productinfo.ProductName.ToString();
                tbUnitPrice.Text = productinfo.UnitPrice.ToString();
                tbWeight.Text = productinfo.Weight.ToString();
            }
        }
    }
}
