
package connectSQLServer;


public interface DatabaseInfor {
    //Chi
//    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//    public static String url = "jdbc:sqlserver://localhost:1433;DatabaseName=SWP391";
//    public static String user = "sa";
//    public static String pass = "123456789";
    //Ni
    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String url = "jdbc:sqlserver://localhost:1433;DatabaseName=SWP391";
    public static String user = "sa";
    public static String pass = "sa";
}
