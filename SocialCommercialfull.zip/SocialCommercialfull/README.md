# SocialCommercial
Software that connects to everyone and allows them to buy and sell everything
